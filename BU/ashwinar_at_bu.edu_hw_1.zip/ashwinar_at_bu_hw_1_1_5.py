#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Jan 27 10:50:09 2019

@author: ashwinak
"""
'''
Compute the result of the expression:

    9.5 * 4.5 - 2.5 * 3
    -------------------
        45.5 - 3.5

The order of operation is: PEMDAS
    
Parentheses, Exponents, Multiplication and Division, Addition and Subtraction

Step1: Multiplication.
    42.75 - 7.5 / 45.5 - 3.5
Step2: Division.
    42.75 - 0.1648 - 3.5
Step3: Subtraction.
    39.0852

'''
print ("##")
print (9.5 * 4.5 - 2.5 * 3/45.5 - 3.5)



