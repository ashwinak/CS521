#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Jan 27 10:38:48 2019

@author: ashwinak
"""

print ('''
       
FFFFFFF  U     U  NN     N 
FF       U     U  NNN    N 
FFFFFFF  U     U  NN N   N 
FF        U   U   NN  N NN 
FF         UUU    NN   NNN

       
       ''')

 