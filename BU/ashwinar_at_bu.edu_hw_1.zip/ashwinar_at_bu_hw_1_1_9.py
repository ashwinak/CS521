#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Jan 27 18:11:34 2019

@author: ashwinak
"""

'''
Program to display the area and perimeter of a rectangle 
width=4.5
height=7.9

'''

widthOfRectangle = 4.5
heightOfRectangle = 7.9

areaOfRectangle = (widthOfRectangle * heightOfRectangle )
perimeterOfRectangle = 2 * (heightOfRectangle + widthOfRectangle)

print("Area of Rectangle is", areaOfRectangle,"\nArea of Rectangle is (Rounded off)",round(areaOfRectangle))
print("Perimeter of Rectangle is", perimeterOfRectangle,"\nPerimeter of Rectangle is (Rounded off)",round(perimeterOfRectangle))


