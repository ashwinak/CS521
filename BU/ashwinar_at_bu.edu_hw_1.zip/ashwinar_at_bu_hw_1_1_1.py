#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Jan 27 10:15:28 2019

@author: ashwinak
"""

##This program is using python 3.7

print ("Welcome to Python",\
       "\nWelcome to Computer Science",\
       "\nProgramming is fun")
